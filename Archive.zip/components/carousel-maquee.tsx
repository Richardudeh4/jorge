import React from 'react'

const CarouselMaquee = () => {
  return (
    <div className='overflow-hidden mt-36 bg-red-600 '>
        <div className='whitespace-nowrap flex flex-row space-x-14 py-6   animate-marquee'>
        <h1 className='text-6xl font-semibold '>$Jorge</h1>
        <h1 className='text-6xl font-semibold '>$Jorge</h1>
        <h1 className='text-6xl font-semibold '>$Jorge</h1>
        <h1 className='text-6xl font-semibold '>$Jorge</h1>
        <h1 className='text-6xl font-semibold '>$Jorge</h1>
        <h1 className='text-6xl font-semibold '>$Jorge</h1>
        <h1 className='text-6xl font-semibold '>$Jorge</h1>
        <h1 className='text-6xl font-semibold '>$Jorge</h1>
        <h1 className='text-6xl font-semibold '>$Jorge</h1>
        <h1 className='text-6xl font-semibold '>$Jorge</h1>
        <h1 className='text-6xl font-semibold '>$Jorge</h1>
        <h1 className='text-6xl font-semibold '>$Jorge</h1>
        <h1 className='text-6xl font-semibold '>$Jorge</h1>
        </div>
      
    </div>
  )
}

export default CarouselMaquee