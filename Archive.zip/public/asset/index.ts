import instagram from "./instagram.svg";
import twiiter from "./twitter.svg";
import telegram from "./telegram.svg";
import tiktok from "./tiktok.svg";
import youtube from "./youtube.svg";


export {
    twiiter, 
    telegram
}